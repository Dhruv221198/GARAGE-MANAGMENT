package com.example.garagemanagement.Activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.garagemanagement.Details.UserDetails;
import com.example.garagemanagement.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignupActivity extends AppCompatActivity {

    EditText name_SS, password_SS, phone_SS, email_SS;
    TextView dob_TV_SS;
    TextInputLayout name_TTL, password_TTL, email_TTL, phone_TTL;
    ImageView profilePic_SS;
    DatabaseReference userRef;
    StorageReference proPicRef;
    private FirebaseAuth mAuth;
    RadioGroup radioGroupgender;
    RadioButton radioButton;

    Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();
        userRef = FirebaseDatabase.getInstance().getReference("User_DB");
        proPicRef = FirebaseStorage.getInstance().getReference("ProfilePic/");

        radioGroupgender = findViewById(R.id.radioGroupGender);
        name_TTL = findViewById(R.id.name_SS_TTL);
        email_TTL = findViewById(R.id.email_SS_TTL);
        password_TTL = findViewById(R.id.password_SS_TTL);
        phone_TTL = findViewById(R.id.phone_SS_TTL);
        profilePic_SS = findViewById(R.id.profilePic_SS);

        name_SS = findViewById(R.id.name_SS);
        password_SS = findViewById(R.id.password_SS);
        phone_SS = findViewById(R.id.phone_SS);
        email_SS = findViewById(R.id.email_SS);
        dob_TV_SS = findViewById(R.id.dob_TV_SS);

        findViewById(R.id.dob_BTN_SS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(SignupActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                dob_TV_SS.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        profilePic_SS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openImageChooser();

            }
        });

        findViewById(R.id.signup_SS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (validation()) {

                    final ProgressDialog progressDialog = new ProgressDialog(SignupActivity.this);
                    progressDialog.setTitle("Uploading Details");

                    int selectedId = radioGroupgender.getCheckedRadioButtonId();

                    radioButton = (RadioButton) findViewById(selectedId);

                    final String gender = radioButton.getText().toString();

                    mAuth.createUserWithEmailAndPassword(email_SS.getText().toString(), password_SS.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        final StorageReference proFileRef = proPicRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid() + "." + getFileExtension(imageUri));

                                        proFileRef.putFile(imageUri)
                                                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                    @Override
                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                        progressDialog.dismiss();

                                                        proFileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                            @Override
                                                            public void onSuccess(Uri uri) {
                                                                String url = uri.toString();

                                                                UserDetails userDetails = new UserDetails(FirebaseAuth.getInstance().getCurrentUser().getUid(),
                                                                        name_SS.getText().toString(), password_SS.getText().toString(),
                                                                        phone_SS.getText().toString(), email_SS.getText().toString(),gender,dob_TV_SS.getText().toString(),url);

                                                                userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userDetails);

                                                            }
                                                        });

                                                        Toast.makeText(SignupActivity.this, "Done", Toast.LENGTH_SHORT).show();

                                                        finish();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        progressDialog.dismiss();
                                                        Toast.makeText(SignupActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                    @Override
                                                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                                        double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                                        progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                                                        progressDialog.show();
                                                    }
                                                });

                                    } else {
                                        Toast.makeText(SignupActivity.this, "Failed to Add New Account", Toast.LENGTH_SHORT).show();
                                    }

                                    progressDialog.dismiss();
                                }
                            });

                }


            }
        });

    }

    private String getFileExtension(Uri uri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    void openImageChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null){

            imageUri = data.getData();

            Picasso.with(this).load(imageUri).into(profilePic_SS);

        }

    }

    boolean validation() {

        if (name_SS.getText().toString().isEmpty()) {
            name_TTL.setError("Enter Name");
        }
        else if (email_SS.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email_SS.getText().toString()).matches()) {
            email_TTL.setError("Enter valid email");
        }
        else if (password_SS.getText().toString().isEmpty() || password_SS.getText().toString().length() < 4 || password_SS.getText().toString().length() > 16) {
            password_TTL.setError("Enter Valid Password ! Password must be between 6 to 16 alphabets");
        }
        else if (imageUri==null){
            Toast.makeText(this, "Profile is not selected", Toast.LENGTH_SHORT).show();
        }
        else if (dob_TV_SS.getText().toString().isEmpty()){
            dob_TV_SS.setError("Select DOB");
        }
        else if (phone_SS.getText().toString().isEmpty() || !Pattern.compile("^[6-9]\\d{9}$").matcher(phone_SS.getText().toString()).matches()) {
            phone_TTL.setError("Enter Valid Phone Number");
        } else {
            return true;
        }

        return false;

    }

}
