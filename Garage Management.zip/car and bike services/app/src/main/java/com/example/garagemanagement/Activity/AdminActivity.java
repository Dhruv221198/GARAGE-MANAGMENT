package com.example.garagemanagement.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.example.garagemanagement.AdminFragments.PickupFragment;
import com.example.garagemanagement.AdminFragments.ServiceFragment;
import com.example.garagemanagement.Details.ItemDetails;
import com.example.garagemanagement.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class AdminActivity extends AppCompatActivity {

    ImageView itemPic;
    Uri imageUri;

    DatabaseReference itemsRef, productPriceRef;
    StorageReference itemStorageRef;

    String[] itemsArray = {"Oil", "Bumfer", "Horn", "Side Mirror", "Battery", "Tyre"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        itemsRef = FirebaseDatabase.getInstance().getReference("Items_DB");
        productPriceRef = FirebaseDatabase.getInstance().getReference("ProductPrice_DB");
        itemStorageRef = FirebaseStorage.getInstance().getReference("Item_Images/");

        getSupportFragmentManager().beginTransaction().replace(R.id.container,new ServiceFragment()).commit();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.admin_items, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.addItems_ID) {
            addItemDialog();
        }
        if (item.getItemId() == R.id.admin_logout) {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(AdminActivity.this,LoginActivity.class));
            finish();
            return true;
        }

        return true;
    }

    void addItemDialog() {

        final Dialog dialog = new Dialog(this);
        dialog.setTitle("Add Items");
        dialog.setContentView(R.layout.additem_dialog);

        final Spinner spinner = dialog.findViewById(R.id.itemList_SP_AI);
        final EditText itemName = dialog.findViewById(R.id.nameItem_ET_AI);
        final EditText itemCost = dialog.findViewById(R.id.costItem_ET_AI);
        itemPic = dialog.findViewById(R.id.picItem_IV_AI);
        Button uploadPic = dialog.findViewById(R.id.uploadItemPic_BT_AI);
        Button submitItem = dialog.findViewById(R.id.addItem_BTN_AI);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, itemsArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        uploadPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openImageChooser();

            }
        });

        submitItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final ProgressDialog progressDialog = new ProgressDialog(AdminActivity.this);
                progressDialog.setTitle("Uploading Item");

                final String product = spinner.getSelectedItem().toString().trim();
                final String name = itemName.getText().toString().trim();
                final String cost = itemCost.getText().toString().trim();

                final String id = FirebaseDatabase.getInstance().getReference().push().getKey();


                if (imageUri == null) {
                    Toast.makeText(AdminActivity.this, "Image Not Selected", Toast.LENGTH_SHORT).show();
                } else if (name.isEmpty()) {
                    itemName.setError("Enter Name");
                } else if (cost.isEmpty()) {
                    itemCost.setError("Enter Cost");
                } else {

                    final StorageReference fileRef = itemStorageRef.child(id + "." + getFileExtension(imageUri));

                    fileRef.putFile(imageUri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    progressDialog.dismiss();

                                    fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {

                                            String url = uri.toString();
                                            ItemDetails itemDetails = new ItemDetails(id, product, name, cost, url);
                                            itemsRef.child(id).setValue(itemDetails);
                                            dialog.dismiss();

                                        }
                                    });


                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    progressDialog.dismiss();
                                    Toast.makeText(AdminActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                    double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                    progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                                    progressDialog.show();
                                }
                            });

                }

            }
        });

        dialog.show();

    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {

            imageUri = data.getData();

            Picasso.with(this).load(imageUri).into(itemPic);

        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}

class MyAdapter extends FragmentPagerAdapter {

    int totalTabs;
    private Context myContext;

    public MyAdapter(@NonNull FragmentManager fm, Context myContext, int totalTabs) {
        super(fm);
        this.myContext = myContext;
        this.totalTabs = totalTabs;
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                ServiceFragment serviceFragment = new ServiceFragment();
                return serviceFragment;

            case 1:
                PickupFragment pickupFragment = new PickupFragment();
                return pickupFragment;

            default:
                return null;
        }

    }

    @Override
    public int getCount() {
        return totalTabs;
    }


}