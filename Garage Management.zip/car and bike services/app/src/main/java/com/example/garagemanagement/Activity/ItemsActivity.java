package com.example.garagemanagement.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.garagemanagement.Details.ItemDetails;
import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.Lists.Item_List;
import com.example.garagemanagement.Lists.Service_List;
import com.example.garagemanagement.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ItemsActivity extends AppCompatActivity {

    ListView item_listView;
    DatabaseReference itemRef;
    List<ItemDetails> itemDetailsList;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        itemRef = FirebaseDatabase.getInstance().getReference("Items_DB");
        item_listView = findViewById(R.id.item_listView);
        itemDetailsList = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        String form = bundle.getString("key");

        user = FirebaseAuth.getInstance().getCurrentUser();

        if (form.equals("12")){

            setTitle("Oil");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Oil")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        if (form.equals("13")){

            setTitle("Tyre");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Tyre")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        if (form.equals("14")){

            setTitle("Horn");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Horn")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        if (form.equals("15")){

            setTitle("Bumfer");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Bumper")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        if (form.equals("16")){

            setTitle("Side Mirror");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Side Mirror")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        if (form.equals("17")){

            setTitle("Battery");

            itemRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    itemDetailsList.clear();

                    for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                        ItemDetails itemDetails = serDatashot.getValue(ItemDetails.class);

                        if (itemDetails.getItem_product().equals("Battery")){

                            itemDetailsList.add(itemDetails);

                        }

                    }

                    Item_List item_list = new Item_List(ItemsActivity.this, itemDetailsList);
                    item_listView.setAdapter(item_list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

    }
}
