package com.example.garagemanagement.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.Lists.Service_List;
import com.example.garagemanagement.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ServicesActivity extends AppCompatActivity {

    ListView ser_listView;
    DatabaseReference serviceRef;
    List<ServiceDetails> serviceDetailsList;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        setTitle("Services");

        serviceRef = FirebaseDatabase.getInstance().getReference("Service_DB");
        ser_listView = findViewById(R.id.ser_listView);
        serviceDetailsList = new ArrayList<>();

        user = FirebaseAuth.getInstance().getCurrentUser();

        serviceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                serviceDetailsList.clear();

                for (DataSnapshot serDatashot:dataSnapshot.getChildren()){

                    ServiceDetails serviceDetails = serDatashot.getValue(ServiceDetails.class);

                    if (serviceDetails.getSer_email().equals(user.getEmail())){

                        serviceDetailsList.add(serviceDetails);

                    }

                }

                Service_List service_list = new Service_List(ServicesActivity.this, serviceDetailsList);
                ser_listView.setAdapter(service_list);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        ser_listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                final ServiceDetails serviceDetails = serviceDetailsList.get(position);

                AlertDialog.Builder builder = new AlertDialog.Builder(ServicesActivity.this);
                builder.setTitle("Ask inquiry");

                builder.setPositiveButton("Ask", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent email = new Intent(Intent.ACTION_SEND);
                        String data = "Service Mode:- " + serviceDetails.getSer_serviceForm() +
                                "\n Vehicle Model:- " + serviceDetails.getSer_vehicle() +
                                "\n Vehicle Number:- " + serviceDetails.getSer_vehNumber()+
                                "\n Date:- " + serviceDetails.getSer_date()+
                                "\n Time:- " + serviceDetails.getSer_time()+
                                "\n Previous Status:- " + serviceDetails.getSer_status()+
                                "\n Comment:- " + serviceDetails.getSer_comment();

                        email.putExtra(Intent.EXTRA_EMAIL, new String[]{ "pk.960388@gmail.com"});
                        email.putExtra(Intent.EXTRA_SUBJECT, "Customer Inquiry");
                        email.putExtra(Intent.EXTRA_TEXT, data);

                        email.setType("message/rfc822");

                        startActivity(Intent.createChooser(email, "Choose an Email client :"));

                        Toast.makeText(ServicesActivity.this, data, Toast.LENGTH_SHORT).show();

                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();


                return false;
            }
        });

    }
}
