package com.example.garagemanagement.Lists;

import android.app.Activity;
import android.app.ActivityOptions;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.example.garagemanagement.Details.ItemDetails;
import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Item_List extends ArrayAdapter<ItemDetails> {

    private Activity context;
    private List<ItemDetails> itemDetailsList;

    public Item_List(Activity context, List<ItemDetails> itemDetailsList){
        super(context, R.layout.item_customlist,itemDetailsList);
        this.context = context;
        this.itemDetailsList = itemDetailsList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        View v= inflater.inflate(R.layout.item_customlist,null);

        final TextView name = v.findViewById(R.id.itemName_CL);
        final ImageView image = v.findViewById(R.id.itemPic_CL);
        final TextView cost = v.findViewById(R.id.itemCost_CL);

        final ItemDetails itemDetails = itemDetailsList.get(position);

        Glide.with(context).load(itemDetails.getItem_pic()).into(image);

        name.setText(itemDetails.getItem_name());
        cost.setText(itemDetails.getItem_cost());

        return v;
    }
}
