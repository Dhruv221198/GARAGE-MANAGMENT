package com.example.garagemanagement.Details;

public class PickUpDetails {

    String Latitude;
    String user_email;
    String longitude;

    public PickUpDetails() {
    }

    public PickUpDetails(String user_email, String latitude, String longitude) {
        Latitude = latitude;
        this.user_email = user_email;
        this.longitude = longitude;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
