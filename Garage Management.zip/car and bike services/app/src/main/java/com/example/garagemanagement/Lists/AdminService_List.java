package com.example.garagemanagement.Lists;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.R;

import java.util.List;

public class AdminService_List extends ArrayAdapter<ServiceDetails> {

    private Context context;
    private List<ServiceDetails> serviceDetailsList ;

    public AdminService_List(Context context, List<ServiceDetails> serviceDetailsList){
        super(context, R.layout.service_admin,serviceDetailsList);
        this.context = context;
        this.serviceDetailsList = serviceDetailsList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.service_admin,null,true);

        TextView nameTV = v.findViewById(R.id.vehName_CList);
        TextView numTV = v.findViewById(R.id.vehNumber_CList);
        TextView dateTV = v.findViewById(R.id.vehDate_CList);
        TextView timeTV = v.findViewById(R.id.vehTime_CList);
        TextView statusTV = v.findViewById(R.id.vehStatus_CList);
        TextView formTV = v.findViewById(R.id.vehForm_CList);
        TextView costTV = v.findViewById(R.id.vehCost_CList);
        TextView commentTV = v.findViewById(R.id.vehComment_CList);

        ServiceDetails serviceDetails = serviceDetailsList.get(position);

        nameTV.setText(serviceDetails.getSer_vehicle());
        numTV.setText(serviceDetails.getSer_vehNumber());
        dateTV.setText(serviceDetails.getSer_date());
        timeTV.setText(serviceDetails.getSer_time());
        statusTV.setText(serviceDetails.getSer_status());
        formTV.setText(serviceDetails.getSer_serviceForm());
        costTV.setText(serviceDetails.getSer_cost());

        if (serviceDetails.getSer_comment().equals("")){

            commentTV.setText("No Comment");

        }else {
            commentTV.setText(serviceDetails.getSer_comment());
        }

        return v;
    }
}
