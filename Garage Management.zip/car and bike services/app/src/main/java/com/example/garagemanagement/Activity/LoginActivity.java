package com.example.garagemanagement.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.garagemanagement.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    TextInputEditText email_LS, password_LS;
    TextInputLayout email_LS_TTL, password_LS_TTL;
    ImageView iconIV;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final ProgressBar progressBar = findViewById(R.id.progress_circular);

        mAuth = FirebaseAuth.getInstance();

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            Intent intent = new Intent(LoginActivity.this,DashboardActivity.class);
            startActivity(intent);
            finish();
        }
        email_LS = findViewById(R.id.email_LS);
        password_LS = findViewById(R.id.password_LS);

        email_LS_TTL = findViewById(R.id.email_LS_TTL);
        password_LS_TTL = findViewById(R.id.password_LS_TTL);

        iconIV = findViewById(R.id.icon_admin);

        iconIV.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);

                LayoutInflater inflater = getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.admin_pass,null);
                builder.setView(dialogView);

                final EditText password = dialogView.findViewById(R.id.adminPass);
                Button loginBtn = dialogView.findViewById(R.id.adminBtn);
                builder.setTitle("Admin Login");
                final AlertDialog alertDialog = builder.create();

                loginBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (password.getText().toString().trim().equals("123456")) {
                            startActivity(new Intent(LoginActivity.this, AdminActivity.class));
                            alertDialog.dismiss();
                        }
                        else {
                            Toast.makeText(LoginActivity.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }
                    }
                });
                alertDialog.show();
                return true;
            }
        });

        findViewById(R.id.login_LS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()){
                    final ProgressDialog progressDialog=new ProgressDialog(LoginActivity.this);
                     progressDialog.setTitle("Verifying Details");
                     progressDialog.show();
                     mAuth.signInWithEmailAndPassword(email_LS.getText().toString().trim(), password_LS.getText().toString().trim())
                            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                                    } else {
                                        Toast.makeText(LoginActivity.this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                                    }
                                    progressDialog.dismiss();
                                }
                            });
                }
            }
        });

        findViewById(R.id.signup_LS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SignupActivity.class));
            }
        });

    }

    boolean validation() {


        if (email_LS.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email_LS.getText().toString()).matches()){
            email_LS_TTL.setError("Enter valid email");
        }

       else  if (password_LS.getText().toString().isEmpty()){
            password_LS_TTL.setError("Enter valid Password");
        }

       else{
           return true;
        }

        return false;

    }

    @Override
    public void onBackPressed() {
        System.exit(0);
    }
}