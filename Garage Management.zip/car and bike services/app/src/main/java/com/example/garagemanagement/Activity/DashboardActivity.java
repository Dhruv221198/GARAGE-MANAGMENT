package com.example.garagemanagement.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.garagemanagement.Details.PickUpDetails;
import com.example.garagemanagement.ImageAdapter;
import com.example.garagemanagement.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class DashboardActivity extends AppCompatActivity {

    DatabaseReference locationRef;
    FirebaseUser user;
    long loc_id = 0;

    ViewPager viewPager;
    int counter=0;

    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        //photoslider

        viewPager = findViewById(R.id.viewPager);
        int[] sliderImageId= new int[]{
                R.drawable.image1, R.drawable.image2, R.drawable.image3,R.drawable.image4, R.drawable.image5, R.drawable.image6, R.drawable.image7,R.drawable.image8
        };
        ImageAdapter adapterView = new ImageAdapter(this,sliderImageId);
        viewPager.setAdapter(adapterView);

        //////////

        //location

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        ////

        findViewById(R.id.expressService_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","1");
                startActivity(intent);

            }
        });

        findViewById(R.id.dentRemoval_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","2");
                startActivity(intent);

            }
        });

        findViewById(R.id.interiorDetailing_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","3");
                startActivity(intent);

            }
        });

        findViewById(R.id.carPolish_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","4");
                startActivity(intent);

            }
        });

        findViewById(R.id.bumperRepainting_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","5");
                startActivity(intent);

            }
        });

        findViewById(R.id.oilChange_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","6");
                startActivity(intent);

            }
        });

        findViewById(R.id.carSpa_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","7");
                startActivity(intent);

            }
        });

        findViewById(R.id.acService_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","8");
                startActivity(intent);

            }
        });

        findViewById(R.id.generalService_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","9");
                startActivity(intent);

            }
        });

        findViewById(R.id.bikeService_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","10");
                startActivity(intent);

            }
        });

        findViewById(R.id.repairJob_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, AddServiceActivity.class);
                intent.putExtra("key","11");
                startActivity(intent);

            }
        });

        findViewById(R.id.extraOil_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
                intent.putExtra("key","12");
                startActivity(intent);

            }
        });
        findViewById(R.id.extraTyre_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
                intent.putExtra("key","13");
                startActivity(intent);

            }
        });
        findViewById(R.id.extraHorn_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
                intent.putExtra("key","14");
                startActivity(intent);

            }
        });
//        findViewById(R.id.extraBunder_LL).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
//                intent.putExtra("key","15");
//                startActivity(intent);
//
//            }
//        });
        findViewById(R.id.extraSideGlass_LL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
                intent.putExtra("key","16");
                startActivity(intent);

            }
        });
//        findViewById(R.id.extraBattery_LL).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent intent = new Intent(DashboardActivity.this, ItemsActivity.class);
//                intent.putExtra("key","17");
//                startActivity(intent);
//
//            }
//        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_item,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        switch (id){

//            case R.id.profile_item_id:
//                startActivity(new Intent(DashboardActivity.this,ProfileActivity.class));
//                return true;

            case R.id.service_item_id:
                startActivity(new Intent(DashboardActivity.this,ServicesActivity.class));
                return true;

            case R.id.feedback_id:
                Intent email = new Intent(Intent.ACTION_SEND);
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{ "Pk.960388@gmail.com"});
                email.putExtra(Intent.EXTRA_SUBJECT, "FeedBack");
                email.setType("message/rfc822");

                startActivity(Intent.createChooser(email, "Choose an Email client :"));
                return  true;

            case R.id.logout_item_id:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(DashboardActivity.this,LoginActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(DashboardActivity.this,LoginActivity.class));
        finish();
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        new Thread(new Runnable() {
            @Override
            public void run() {

                while (counter<=4){

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            viewPager.setCurrentItem(counter,true);
                            counter++;
                        }
                    });


                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    if(counter>4){
                        counter=0;
                    }

                }

            }
        }).start();
    }
}