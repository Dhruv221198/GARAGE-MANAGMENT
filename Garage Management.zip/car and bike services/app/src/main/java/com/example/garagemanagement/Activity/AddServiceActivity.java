package com.example.garagemanagement.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class AddServiceActivity extends AppCompatActivity {

    TextView serForm_TV,serCost_TV,serDate_TV,serTime_TV,serComment_ET;
    EditText serVehName_ET,serVehNo_ET;

    DatabaseReference serviceRef;
    FirebaseUser user;

    long ser_id=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_service);

        setTitle("Book Service");

        serForm_TV = findViewById(R.id.serForm_TV);
        serCost_TV = findViewById(R.id.serCost_TV);
        serDate_TV = findViewById(R.id.serDate_TV);
        serTime_TV = findViewById(R.id.serTime_TV);

        serComment_ET = findViewById(R.id.serComment_ET);
        serVehName_ET = findViewById(R.id.serVehName_ET);
        serVehNo_ET = findViewById(R.id.serVehNo_ET);

        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        String form = bundle.getString("key");

        user = FirebaseAuth.getInstance().getCurrentUser();
        serviceRef = FirebaseDatabase.getInstance().getReference("Service_DB");

        assert form != null;
        if (form.equals("1")) {

            serForm_TV.setText("Express Service");
            serCost_TV.setText("1200");

        }

        if (form.equals("2")) {

            serForm_TV.setText("Dent/Scratch Removal");
            serCost_TV.setText("800");
        }

        if (form.equals("3")) {

            serForm_TV.setText("Interior Detailing");
            serCost_TV.setText("3600");
        }

        if (form.equals("4")) {

            serForm_TV.setText("Car Polish");
            serCost_TV.setText("600");
        }

        if (form.equals("5")) {

            serForm_TV.setText("Bumfer Repainting");
            serCost_TV.setText("1800");
        }

        if (form.equals("6")) {

            serForm_TV.setText("Oil Change");
            serCost_TV.setText("450");
        }

        if (form.equals("7")) {

            serForm_TV.setText("Car Spa");
            serCost_TV.setText("800");
        }

        if (form.equals("8")) {

            serForm_TV.setText("AC Service");
            serCost_TV.setText("2300");
        }

        if (form.equals("9")) {

            serForm_TV.setText("General Service");
            serCost_TV.setText("450");
        }

        if (form.equals("10")) {

            serForm_TV.setText("Bike Service");
            serCost_TV.setText("800");
        }

        if (form.equals("11")) {

            serForm_TV.setText("Repair Job");
            serCost_TV.setText("600");
        }


        findViewById(R.id.serDate_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(AddServiceActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                serDate_TV.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        findViewById(R.id.serTime_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Calendar c = Calendar.getInstance();
                int mHour = c.get(Calendar.HOUR_OF_DAY);
                int mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddServiceActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                if (hourOfDay > 10 && hourOfDay < 18) {

                                    serTime_TV.setText(hourOfDay + ":" + minute);

                                } else {
                                    Toast.makeText(AddServiceActivity.this, "Enter valid time", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
                findViewById(R.id.serSubmit_btn).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        int notificationID = 0;

                        if (validation()) {

                            String userEmail = user.getEmail();
                            String serForm = serForm_TV.getText().toString().trim();
                            String serCost = serCost_TV.getText().toString().trim();
                            String serVehName = serVehName_ET.getText().toString().trim();
                            String serVehNo = serVehNo_ET.getText().toString().trim();
                            String serDate = serDate_TV.getText().toString().trim();
                            String serTime = serTime_TV.getText().toString().trim();
                            String serStatus = "Pending";
                            String serComment = serComment_ET.getText().toString().trim();

                            String autoID = FirebaseDatabase.getInstance().getReference().push().getKey();

                            ServiceDetails serviceDetails = new ServiceDetails(autoID, userEmail, serForm, serCost, serVehName,
                                    serVehNo, serDate, serTime, serStatus, serComment);
                            serviceRef.child(autoID).setValue(serviceDetails);

                            Toast.makeText(AddServiceActivity.this, "Service Added", Toast.LENGTH_SHORT).show();

                            startActivity(new Intent(AddServiceActivity.this, DashboardActivity.class));

                            NotificationCompat.Builder builder = new NotificationCompat.Builder(AddServiceActivity.this).
                                    setSmallIcon(R.drawable.ic_baseline_circle_notifications_24).
                                    setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_baseline_circle_notifications_24)).
                                    setContentTitle("Garage Management").
                                    setContentText("Update related to your booked service").
                                    setAutoCancel(true).
                                    setDefaults(NotificationCompat.DEFAULT_ALL);

                            Uri path = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                            builder.setSound(path);

                            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                String channelID = "YOUR_CHANNEL_ID";
                                NotificationChannel channel = new NotificationChannel(channelID, "Channel human readable title", NotificationManager.IMPORTANCE_DEFAULT);
                                notificationManager.createNotificationChannel(channel);
                                builder.setChannelId(channelID);

                            }
                            notificationManager.notify(notificationID, builder.build());

                        }

                    }
                });

            }

            boolean validation() {

                if (serVehName_ET.getText().toString().isEmpty()) {
                    serVehName_ET.setError("Enter Vehicle Name");
                } else if (serVehNo_ET.getText().toString().isEmpty()) {
                    serVehNo_ET.setError("Enter Vehicle Number");
                } else if (serDate_TV.getText().toString().isEmpty()) {
                    serDate_TV.setError("Select Date");
                } else if (serTime_TV.getText().toString().isEmpty()) {
                    serTime_TV.setError("Select Time");
                } else {
                    return true;
                }

                return false;

            }
        });

    }}