package com.example.garagemanagement.Lists;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.garagemanagement.Details.PickUpDetails;
import com.example.garagemanagement.R;

import java.util.List;

public class AdminPickUp_List extends ArrayAdapter<PickUpDetails> {

    private Context context;
    private List<PickUpDetails> pickUpDetailsList;

    public AdminPickUp_List(Context context, List<PickUpDetails> pickUpDetailsList) {
        super(context, R.layout.location_admin,pickUpDetailsList);
        this.context = context;
        this.pickUpDetailsList = pickUpDetailsList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);

        View v = inflater.inflate(R.layout.location_admin,null,true);

        TextView emailTV = v.findViewById(R.id.emailLoc_admin);
        TextView latTV = v.findViewById(R.id.lat_admin_CList);
        TextView longTV = v.findViewById(R.id.long_admin_CList);

        PickUpDetails pickUpDetails = pickUpDetailsList.get(position);

        emailTV.setText(pickUpDetails.getUser_email());
        latTV.setText(pickUpDetails.getLatitude());
        longTV.setText(pickUpDetails.getLongitude());

        return v;
    }
}