package com.example.garagemanagement.Details;

public class ServiceDetails {

    String ser_id;
    String ser_email;
    String ser_serviceForm;
    String ser_cost;
    String ser_vehicle;
    String ser_vehNumber;
    String ser_date;
    String ser_time;
    String ser_status;
    String ser_comment;

    public ServiceDetails() {
    }

    public ServiceDetails(String ser_id, String ser_email, String ser_serviceForm, String ser_cost, String ser_vehicle, String ser_vehNumber, String ser_date, String ser_time, String ser_status, String ser_comment) {
        this.ser_id = ser_id;
        this.ser_email = ser_email;
        this.ser_serviceForm = ser_serviceForm;
        this.ser_cost = ser_cost;
        this.ser_vehicle = ser_vehicle;
        this.ser_vehNumber = ser_vehNumber;
        this.ser_date = ser_date;
        this.ser_time = ser_time;
        this.ser_status = ser_status;
        this.ser_comment = ser_comment;
    }

    public String getSer_serviceForm() {
        return ser_serviceForm;
    }

    public void setSer_serviceForm(String ser_serviceForm) {
        this.ser_serviceForm = ser_serviceForm;
    }

    public String getSer_comment() {
        return ser_comment;
    }

    public void setSer_comment(String ser_comment) {
        this.ser_comment = ser_comment;
    }

    public String getSer_vehNumber() {
        return ser_vehNumber;
    }

    public void setSer_vehNumber(String ser_vehNumber) {
        this.ser_vehNumber = ser_vehNumber;
    }

    public String getSer_cost() {
        return ser_cost;
    }

    public void setSer_cost(String ser_cost) {
        this.ser_cost = ser_cost;
    }

    public String getSer_id() {
        return ser_id;
    }

    public void setSer_id(String ser_id) {
        this.ser_id = ser_id;
    }

    public String getSer_email() {
        return ser_email;
    }

    public void setSer_email(String ser_email) {
        this.ser_email = ser_email;
    }

    public String getSer_vehicle() {
        return ser_vehicle;
    }

    public void setSer_vehicle(String ser_vehicle) {
        this.ser_vehicle = ser_vehicle;
    }

    public String getSer_date() {
        return ser_date;
    }

    public void setSer_date(String ser_date) {
        this.ser_date = ser_date;
    }

    public String getSer_time() {
        return ser_time;
    }

    public void setSer_time(String ser_time) {
        this.ser_time = ser_time;
    }

    public String getSer_status() {
        return ser_status;
    }

    public void setSer_status(String ser_status) {
        this.ser_status = ser_status;
    }
}
