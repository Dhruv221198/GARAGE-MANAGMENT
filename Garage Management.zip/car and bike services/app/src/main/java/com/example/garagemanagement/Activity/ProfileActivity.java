package com.example.garagemanagement.Activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.renderscript.ScriptIntrinsicYuvToRGB;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.garagemanagement.Details.UserDetails;
import com.example.garagemanagement.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    EditText pro_name, pro_email, pro_number;
    TextView dob_TV_SS;
    RadioGroup radioGroupgender;
    RadioButton radioButtonMale,radioButtonFemale,radioButton;
    String pro_password;

    String pre_name,pre_email,pre_number,pre_dob,pre_gender;

    DatabaseReference userRef;
    StorageReference proPic_ref;
    Uri imageUri;

    String proUrl;
    ImageView pro_pic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        setTitle("Profile");

        pro_email = findViewById(R.id.pro_email);
        pro_name = findViewById(R.id.pro_name);
        pro_number = findViewById(R.id.pro_number);
        pro_pic = findViewById(R.id.pro_pic);
        dob_TV_SS = findViewById(R.id.dob_TV_SS);
        radioGroupgender = findViewById(R.id.radioGroupGender);
        radioButtonFemale = findViewById(R.id.female_RB);
        radioButtonMale = findViewById(R.id.male_RB);

        userRef = FirebaseDatabase.getInstance().getReference().child("User_DB");
        proPic_ref = FirebaseStorage.getInstance().getReference("ProfilePic/");

        pro_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openImageChooser();

            }
        });


        userRef.child(FirebaseAuth.getInstance().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                pre_name = dataSnapshot.child("user_name").getValue().toString();
                pre_email = dataSnapshot.child("user_email").getValue().toString();
                pre_number = dataSnapshot.child("user_phone").getValue().toString();
                pro_password = dataSnapshot.child("user_password").getValue().toString();
                proUrl = dataSnapshot.child("user_pro").getValue().toString();
                pre_dob = dataSnapshot.child("user_dob").getValue().toString();
                pre_gender = dataSnapshot.child("user_gender").getValue().toString();

                if (pre_gender.equals("Male")){
                    radioButtonMale.setChecked(true);
                }
                else if (pre_gender.equals("Female")){
                    radioButtonFemale.setChecked(true);
                }

                pro_email.setText(pre_email);
                pro_name.setText(pre_name);
                dob_TV_SS.setText(pre_dob);
                pro_number.setText(pre_number);
                Picasso.with(ProfileActivity.this).load(proUrl).fit().centerCrop().into(pro_pic);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        findViewById(R.id.savePro_BTN).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String id = FirebaseAuth.getInstance().getCurrentUser().getUid();

                final StorageReference proFileRef = proPic_ref.child(FirebaseAuth.getInstance().getCurrentUser().getUid() + "." + getFileExtension(imageUri));

                final ProgressDialog progressDialog = new ProgressDialog(ProfileActivity.this);
                progressDialog.setTitle("Uploading Details");

                proFileRef.putFile(imageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                progressDialog.dismiss();

                                proFileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        String url = uri.toString();

                                        UserDetails userDetails = new UserDetails(id, pre_name, pro_password, pre_number, pre_email, pre_gender, pre_dob, url);

                                        AuthCredential credential = EmailAuthProvider
                                                .getCredential(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString(), pro_password);

                                        FirebaseAuth.getInstance().getCurrentUser().reauthenticate(credential)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {

                                                        FirebaseAuth.getInstance().getCurrentUser().updateEmail(pre_email);

                                                    }
                                                });

                                        userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userDetails);

                                        startActivity(new Intent(ProfileActivity.this, DashboardActivity.class));

                                    }
                                });

                                finish();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.dismiss();
                                Toast.makeText(ProfileActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                                progressDialog.show();
                            }
                        });

            }
        });

        findViewById(R.id.dob_BTN_SS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(ProfileActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                dob_TV_SS.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {

            imageUri = data.getData();

            Picasso.with(this).load(imageUri).into(pro_pic);

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.profile_item, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        switch (id) {

            case R.id.saveProfile:

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Do you want to update you profile");
                builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (validation()) {

                            final ProgressDialog progressDialog = new ProgressDialog(ProfileActivity.this);
                            progressDialog.setTitle("Uploading Details");

                            final String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                            final String password = pro_password;
                            final String name = pro_name.getText().toString().trim();
                            final String email = pro_email.getText().toString().trim();
                            final String number = pro_number.getText().toString().trim();
                            final String dob = dob_TV_SS.getText().toString().trim();

                            int selectedId = radioGroupgender.getCheckedRadioButtonId();

                            radioButton = (RadioButton) findViewById(selectedId);

                            final String gender = radioButton.getText().toString();

                            UserDetails userDetails = new UserDetails(id, name, password, number, email, gender, dob, proUrl);

                            AuthCredential credential = EmailAuthProvider
                                    .getCredential(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString(), password);

                            FirebaseAuth.getInstance().getCurrentUser().reauthenticate(credential)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            FirebaseAuth.getInstance().getCurrentUser().updateEmail(email);

                                        }
                                    });

                            userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userDetails);

                            startActivity(new Intent(ProfileActivity.this, DashboardActivity.class));

                            Toast.makeText(ProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();

                        }

                    }
                })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                startActivity(new Intent(ProfileActivity.this, DashboardActivity.class));

                                Toast.makeText(ProfileActivity.this, "Cancel", Toast.LENGTH_SHORT).show();

                            }
                        });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    boolean validation() {

        if (pro_name.getText().toString().isEmpty()) {
            pro_name.setError("Enter Name");
        } else if (pro_email.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(pro_email.getText().toString()).matches()) {
            pro_email.setError("Enter valid email");
        }
        if (pro_number.getText().toString().isEmpty() || !Pattern.compile("^[6-9]\\d{9}$").matcher(pro_number.getText().toString()).matches()) {
            pro_number.setError("Enter Valid Phone Number");
        } else {
            return true;
        }

        return false;

    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Do you want to update you profile");
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (validation()) {

                    final ProgressDialog progressDialog = new ProgressDialog(ProfileActivity.this);
                    progressDialog.setTitle("Uploading Details");

                    final String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    final String password = pro_password;
                    final String name = pro_name.getText().toString().trim();
                    final String email = pro_email.getText().toString().trim();
                    final String number = pro_number.getText().toString().trim();
                    final String dob = dob_TV_SS.getText().toString().trim();

                    int selectedId = radioGroupgender.getCheckedRadioButtonId();

                    radioButton = (RadioButton) findViewById(selectedId);

                    final String gender = radioButton.getText().toString();

                    UserDetails userDetails = new UserDetails(id, name, password, number, email, gender, dob, proUrl);

                    AuthCredential credential = EmailAuthProvider
                            .getCredential(FirebaseAuth.getInstance().getCurrentUser().getEmail().toString(), password);

                    FirebaseAuth.getInstance().getCurrentUser().reauthenticate(credential)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    FirebaseAuth.getInstance().getCurrentUser().updateEmail(email);

                                }
                            });

                    userRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userDetails);

                    startActivity(new Intent(ProfileActivity.this, DashboardActivity.class));

                    Toast.makeText(ProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();

                }

            }
        })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        startActivity(new Intent(ProfileActivity.this, DashboardActivity.class));

                        Toast.makeText(ProfileActivity.this, "Cancel", Toast.LENGTH_SHORT).show();

                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }
}
