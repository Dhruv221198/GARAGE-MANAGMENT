package com.example.garagemanagement.AdminFragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.garagemanagement.Activity.DashboardActivity;
import com.example.garagemanagement.Activity.LoginActivity;
import com.example.garagemanagement.Activity.ProfileActivity;
import com.example.garagemanagement.Activity.ServicesActivity;
import com.example.garagemanagement.Details.ServiceDetails;
import com.example.garagemanagement.Lists.AdminService_List;
import com.example.garagemanagement.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ServiceFragment extends Fragment {

    DatabaseReference serviceRef;
    ListView ser_admin_listView;
    List<ServiceDetails> serviceDetailsList;

    String key;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v = inflater.inflate(R.layout.fragment_service, container, false);

        ser_admin_listView = v.findViewById(R.id.ser_adminList);

        serviceRef = FirebaseDatabase.getInstance().getReference("Service_DB");

        serviceDetailsList = new ArrayList<>();

        serviceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                serviceDetailsList.clear();

                for (DataSnapshot serDatashot : dataSnapshot.getChildren()) {

                    ServiceDetails vehicleDetails = serDatashot.getValue(ServiceDetails.class);
                    serviceDetailsList.add(vehicleDetails);

                }

                AdminService_List adminService_list = new AdminService_List(getContext(), serviceDetailsList);
                ser_admin_listView.setAdapter(adminService_list);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        ser_admin_listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                ServiceDetails serviceDetails = serviceDetailsList.get(position);

                updateStatus(serviceDetails.getSer_id(),serviceDetails.getSer_email(),serviceDetails.getSer_serviceForm(),serviceDetails.getSer_cost(),
                        serviceDetails.getSer_vehicle(),serviceDetails.getSer_vehNumber(),serviceDetails.getSer_date(),serviceDetails.getSer_time(),
                        serviceDetails.getSer_status(),serviceDetails.getSer_comment());

                Toast.makeText(getContext(), String.valueOf(serviceDetails), Toast.LENGTH_SHORT).show();

                return true;
            }
        });


        return v;
    }

    void updateStatus(final String id, final String email, final String serForm, final String cost, final String vehicle, final String vehNum,
                      final String date, final String time,final String status,final String comment){

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = getLayoutInflater();

        View dialogView = inflater.inflate(R.layout.update_status,null);

        builder.setView(dialogView);

        final EditText statusET = dialogView.findViewById(R.id.status_update);
        final EditText costET = dialogView.findViewById(R.id.cost_update);
        Button updateBtn = dialogView.findViewById(R.id.update_statusBtn);

        builder.setTitle("Enter Price");

        final AlertDialog alertDialog = builder.create();

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fstatus = statusET.getText().toString().trim();
                String fcost = costET.getText().toString().trim();

                ServiceDetails serviceDetails = new ServiceDetails(id,email,serForm,fcost,vehicle,vehNum,date,time,fstatus,comment);

                serviceRef.child(id).setValue(serviceDetails);

                Toast.makeText(getContext(), "Updated", Toast.LENGTH_SHORT).show();

                alertDialog.dismiss();

            }
        });

        alertDialog.show();

    }

}