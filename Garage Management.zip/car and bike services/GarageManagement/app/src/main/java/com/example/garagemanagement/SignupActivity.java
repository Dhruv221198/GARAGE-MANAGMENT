package com.example.garagemanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class SignupActivity extends AppCompatActivity {

    EditText name_SS, password_SS, confirmPassword_SS, dob_SS, email_SS;
    RadioGroup radioGroup;
    RadioButton gender_SS;
    String name, password, confirmPassword, dob, email, gender;

    private FirebaseAuth mAuth;
    DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();
        userRef = FirebaseDatabase.getInstance().getReference("User_DB");

        name_SS = findViewById(R.id.name_SS);
        password_SS = findViewById(R.id.password_SS);
        confirmPassword_SS = findViewById(R.id.confirmPassword_SS);
        dob_SS = findViewById(R.id.dob_SS);
        email_SS = findViewById(R.id.email_SS);
        radioGroup = findViewById(R.id.radioGroup);

        findViewById(R.id.dob_btn_SS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(SignupActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                dob_SS.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        findViewById(R.id.signup_SS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addUser();



            }
        });

    }

    void getData() {

        name = name_SS.getText().toString().trim();
        password = password_SS.getText().toString().trim();
        confirmPassword = confirmPassword_SS.getText().toString().trim();
        dob = dob_SS.getText().toString().trim();
        email = email_SS.getText().toString().trim();

        int selectedId = radioGroup.getCheckedRadioButtonId();

        // find the radiobutton by returned id
        gender_SS = findViewById(selectedId);

        gender = gender_SS.getText().toString().trim();


    }

    void addUser(){

        getData();

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information

                            String userid = userRef.push().getKey();

                            UserDetails userDetails= new UserDetails(userid,name,password,dob,email,gender);

                            userRef.child(userid).setValue(userDetails);

                            Toast.makeText(SignupActivity.this, "Done", Toast.LENGTH_SHORT).show();

                            startActivity(new Intent());

                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(SignupActivity.this, "Check Details", Toast.LENGTH_SHORT).show();
                        }

                    }

    }); }
}
